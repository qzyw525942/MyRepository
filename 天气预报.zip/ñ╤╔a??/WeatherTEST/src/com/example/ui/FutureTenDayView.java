package com.example.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.weathertest.R;

public class FutureTenDayView extends LinearLayout
{

	private ImageView iv_code1;
	private ImageView iv_code2;
	private TextView tv_text;
	private TextView tv_high_low;
	private TextView tv_wind;
	private TextView tv_data_time;

	public FutureTenDayView(Context context, AttributeSet attrs, int defStyle)
	{
		super(context, attrs, defStyle);
		init();
	}

	public FutureTenDayView(Context context, AttributeSet attrs)
	{
		super(context, attrs);
		init();
	}

	public FutureTenDayView(Context context)
	{
		super(context);
		init();
	}

	public void init()
	{
		View view = View.inflate(getContext(), R.layout.futuretenday, this);

		iv_code1 = (ImageView) view.findViewById(R.id.iv_code1);
		iv_code2 = (ImageView) view.findViewById(R.id.iv_code2);
		tv_text = (TextView) view.findViewById(R.id.tv_text);
		tv_high_low = (TextView) view.findViewById(R.id.tv_high_low);
		tv_wind = (TextView) view.findViewById(R.id.tv_wind);
		tv_data_time = (TextView) view.findViewById(R.id.tv_data_time);

	}

	public void setIv1Icon(int id)
	{
		iv_code1.setBackgroundResource(id);
	}

	public void setIv2Icon(int id)
	{
		iv_code2.setBackgroundResource(id);
	}

	public void setText(String text)
	{
		tv_text.setText(text);
	}

	public void setHigh_Low(String high_low)
	{
		tv_high_low.setText(high_low);
	}

	public void setWind(String wind)
	{
		tv_wind.setText(wind);
	}

	public void setData_Time(String data_time)
	{
		tv_data_time.setText(data_time);
	}
}
