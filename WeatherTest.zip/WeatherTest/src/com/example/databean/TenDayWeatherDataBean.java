package com.example.databean;

import java.util.ArrayList;

/*
 * 使用Gson解析数据时，DataBean的创建技巧：
 * 1、遇到大括号就创建类(Json对象)；遇到中括号创建集合(Json数组)；
 * 2、所有的内部类都是平级的，不能嵌套
 * 3、所有的键名要和返回数据的键名一致
 * 4、所有的类都实现toString方法
 * 5、遇到"data"{...}类型的，就创建对象
 */
public class TenDayWeatherDataBean
{
	public String status; // 是否返回数据
	public ArrayList<Data> weather;// 天气数据集合

	/**
	 * 天气数据类
	 */
	public class Data
	{
		public String city_name;
		public ArrayList<FutureTenDayWeather> future;// 未来十日天气数据集合
		public String last_update; // 上次天气更新时间
		public Now now; // 当前天气情况
		public Today today; // 今日建议

		@Override
		public String toString()
		{
			return "Data [future=" + future + ", last_update=" + last_update
					+ ", now=" + now + ", today=" + today + "]";
		}

	}

	/**
	 * 未来十日天气数据
	 * 
	 */
	public class FutureTenDayWeather
	{
		public double code1; // 最高温图标
		public double code2;// 最低温图标
		public String date;// 日期
		public String day;// 星期
		public double high;// 最高温
		public double low;// 最低温
		public String text;// 描述
		public String wind;// 风力

		@Override
		public String toString()
		{
			return "FutureTenDayWeather [code1=" + code1 + ", code2=" + code2
					+ ", date=" + date + ", day=" + day + ", high=" + high
					+ ", low=" + low + ", text=" + text + ", wind=" + wind
					+ "]";
		}

	}

	/**
	 * 当前天气情况
	 */
	public class Now
	{

		public double code; // 天气图标
		public double feels_like; // 体感
		public double humidity; // 空气湿度
		public double pressure;// 气压
		public String pressure_rising;// 压力等级
		public double temperature;// 温度
		public String text; // 描述
		public double visibility;// 能见度
		public String wind_direction;// 风向
		public double wind_scale;// 风力
		public double wind_speed;// 风速

		public Air_Quality air_quality;// 当前空气质量

		@Override
		public String toString()
		{
			return "Now [code=" + code + ", feels_like=" + feels_like
					+ ", humidity=" + humidity + ", pressure=" + pressure
					+ ", pressure_rising=" + pressure_rising + ", temperature="
					+ temperature + ", text=" + text + ", visibility="
					+ visibility + ", wind_direction=" + wind_direction
					+ ", wind_scale=" + wind_scale + ", wind_speed="
					+ wind_speed + ", air_quality=" + air_quality + "]";
		}

	}

	/**
	 * 当前空气质量类
	 */
	public class Air_Quality
	{
		public City city;

		@Override
		public String toString()
		{
			return "Air_Quality [city=" + city + "]";
		}

	}

	/**
	 * 当前空气质量数据
	 */
	public class City
	{
		public double aqi;
		public double co;
		public String last_update;
		public double no2;
		public double o3;
		public double pm10;
		public double pm25;
		public String quality;
		public double so2;

		@Override
		public String toString()
		{
			return "City [aqi=" + aqi + ", co=" + co + ", last_update="
					+ last_update + ", no2=" + no2 + ", o3=" + o3 + ", pm10="
					+ pm10 + ", pm25=" + pm25 + ", quality=" + quality
					+ ", so2=" + so2 + "]";
		}

	}

	/**
	 * 今日建议类
	 */
	public class Today
	{
		public String sunrise;
		public String sunset;
		public Suggestion suggestion;

		@Override
		public String toString()
		{
			return "Today [sunrise=" + sunrise + ", sunset=" + sunset
					+ ", suggestion=" + suggestion + "]";
		}

	}

	/**
	 * 建议内容
	 */
	public class Suggestion
	{
		public Car_Washing car_washing;
		public Dressing dressing;
		public Flu flu;
		public Sport sport;
		public Travel travel;
		public Uv uv;

		@Override
		public String toString()
		{
			return "Suggestion [car_washing=" + car_washing + ", dressing="
					+ dressing + ", flu=" + flu + ", sport=" + sport
					+ ", travel=" + travel + ", uv=" + uv + "]";
		}

	}

	public class Car_Washing
	{
		public String brief;
		public String details;

		@Override
		public String toString()
		{
			return "Car_Washing [brief=" + brief + ", details=" + details + "]";
		}

	}

	public class Dressing
	{
		public String brief;
		public String details;

		@Override
		public String toString()
		{
			return "Dressing [brief=" + brief + ", details=" + details + "]";
		}

	}

	public class Flu
	{
		public String brief;
		public String details;

		@Override
		public String toString()
		{
			return "Flu [brief=" + brief + ", details=" + details + "]";
		}

	}

	public class Sport
	{
		public String brief;
		public String details;

		@Override
		public String toString()
		{
			return "Sport [brief=" + brief + ", details=" + details + "]";
		}

	}

	public class Travel
	{
		public String brief;
		public String details;

		@Override
		public String toString()
		{
			return "Travel [brief=" + brief + ", details=" + details + "]";
		}

	}

	public class Uv
	{
		public String brief;
		public String details;

		@Override
		public String toString()
		{
			return "Uv [brief=" + brief + ", details=" + details + "]";
		}

	}

	@Override
	public String toString()
	{
		return "TenDayWeatherDataBean [status=" + status + ", weather="
				+ weather + "]";
	}

}
