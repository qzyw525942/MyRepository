package com.example.weathertest;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.databean.CityIdDataBean;
import com.example.databean.TenDayWeatherDataBean;
import com.example.databean.TenDayWeatherDataBean.FutureTenDayWeather;
import com.example.ui.FutureTenDayView;
import com.example.utils.HttpUtils;
import com.example.utils.HttpUtils.HttpCallBack;
import com.example.utils.PinYinUtil;
import com.google.gson.Gson;

public class MainActivity extends Activity
{

	private Button btn_changeCity;
	private ProgressBar pb_btn_changeCity;
	private TextView tv_titleCity;
	private Button btn_updateCityData;
	private TextView tv_sunrise;
	private ImageView iv_icon;
	private TextView tv_sunset;
	private TextView tv_text;
	private TextView tv_temp;
	private LinearLayout hsl_ll;

	private AlertDialog dialog;

	private TextView tv_quality;
	private TextView tv_aqi;
	private TextView tv_humidity;
	private TextView tv_pressure;
	private TextView tv_visibility;
	private TextView tv_wind_direction;
	private TextView tv_wind_scale;
	private TextView tv_wind_speed;
	private TextView tv_pm10;
	private TextView tv_pm25;
	private TextView tv_co;
	private TextView tv_no2;
	private TextView tv_o3;
	private TextView tv_so2;

	private TextView tv_car_washing_brief;
	private TextView tv_car_washing_details;
	private TextView tv_dressing_brief;
	private TextView tv_dressing_detail;
	private TextView tv_flu_brief;
	private TextView tv_flu_details;
	private TextView tv_sport_brief;
	private TextView tv_sport_details;
	private TextView tv_travel_brief;
	private TextView tv_travel_details;
	private TextView tv_uv_brief;
	private TextView tv_uv_details;

	private String getCityLocationURL = "http://api.jirengu.com/city.php?callback=getCity";
	private String getCityIdURL = "https://weixin.jirengu.com/weather/cityid?location=";
	private String get24hourWeatherURL = "https://weixin.jirengu.com/weather/future24h?cityid=";
	private String getTenDayWeatherURL = "https://weixin.jirengu.com/weather/now?cityid=";

	public int[] img_ids = { R.drawable.w_0, R.drawable.w_1, R.drawable.w_2,
			R.drawable.w_3, R.drawable.w_4, R.drawable.w_5, R.drawable.w_6,
			R.drawable.w_7, R.drawable.w_8, R.drawable.w_9, R.drawable.w_10,
			R.drawable.w_11, R.drawable.w_12, R.drawable.w_13, R.drawable.w_14,
			R.drawable.w_15, R.drawable.w_16, R.drawable.w_17, R.drawable.w_18,
			R.drawable.w_19, R.drawable.w_20, R.drawable.w_21, R.drawable.w_22,
			R.drawable.w_23, R.drawable.w_24, R.drawable.w_25, R.drawable.w_26,
			R.drawable.w_27, R.drawable.w_28, R.drawable.w_29, R.drawable.w_30,
			R.drawable.w_31, R.drawable.w_32, R.drawable.w_33, R.drawable.w_34,
			R.drawable.w_35, R.drawable.w_36, R.drawable.w_37, R.drawable.w_38, };

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);

		initView();

		// 设置风车动画
		RotateAnimation animation = new RotateAnimation(0, 360,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF,
				0.5f);

		AutoLocation();

	}

	public void initView()
	{
		btn_changeCity = (Button) findViewById(R.id.btn_changeCity);
		pb_btn_changeCity = (ProgressBar) findViewById(R.id.pb_btn_changeCity);
		tv_titleCity = (TextView) findViewById(R.id.tv_titleCity);
		btn_updateCityData = (Button) findViewById(R.id.btn_updateCityData);
		tv_sunrise = (TextView) findViewById(R.id.tv_sunrise);
		iv_icon = (ImageView) findViewById(R.id.iv_icon);
		tv_sunset = (TextView) findViewById(R.id.tv_sunset);
		tv_text = (TextView) findViewById(R.id.tv_text);
		tv_temp = (TextView) findViewById(R.id.tv_temp);
		hsl_ll = (LinearLayout) findViewById(R.id.hsl_ll);

		// 以下为空气情况的控件
		tv_quality = (TextView) findViewById(R.id.tv_quality);
		tv_aqi = (TextView) findViewById(R.id.tv_aqi);
		tv_humidity = (TextView) findViewById(R.id.tv_humidity);
		tv_pressure = (TextView) findViewById(R.id.tv_pressure);
		tv_visibility = (TextView) findViewById(R.id.tv_visibility);
		tv_wind_direction = (TextView) findViewById(R.id.tv_wind_direction);
		tv_wind_scale = (TextView) findViewById(R.id.tv_wind_scale);
		tv_wind_speed = (TextView) findViewById(R.id.tv_wind_speed);
		tv_pm10 = (TextView) findViewById(R.id.tv_pm10);
		tv_pm25 = (TextView) findViewById(R.id.tv_pm25);
		tv_co = (TextView) findViewById(R.id.tv_co);
		tv_no2 = (TextView) findViewById(R.id.tv_no2);
		tv_o3 = (TextView) findViewById(R.id.tv_o3);
		tv_so2 = (TextView) findViewById(R.id.tv_so2);

		// 以下为建议的控件

		tv_car_washing_brief = (TextView) findViewById(R.id.tv_car_washing_brief);
		tv_car_washing_details = (TextView) findViewById(R.id.tv_car_washing_details);

		tv_dressing_brief = (TextView) findViewById(R.id.tv_dressing_brief);
		tv_dressing_detail = (TextView) findViewById(R.id.tv_dressing_detail);

		tv_flu_brief = (TextView) findViewById(R.id.tv_flu_brief);
		tv_flu_details = (TextView) findViewById(R.id.tv_flu_details);

		tv_sport_brief = (TextView) findViewById(R.id.tv_sport_brief);
		tv_sport_details = (TextView) findViewById(R.id.tv_sport_details);

		tv_travel_brief = (TextView) findViewById(R.id.tv_travel_brief);
		tv_travel_details = (TextView) findViewById(R.id.tv_travel_details);

		tv_uv_brief = (TextView) findViewById(R.id.tv_uv_brief);
		tv_uv_details = (TextView) findViewById(R.id.tv_uv_details);

	}

	/**
	 * 第一步：初始进入程序，自动定位获取城市名
	 */
	public void AutoLocation()
	{

		new HttpUtils().getMethod(getCityLocationURL, new HttpCallBack()
		{

			@Override
			public void onstart()
			{
				btn_changeCity.setVisibility(View.INVISIBLE);
				pb_btn_changeCity.setVisibility(View.VISIBLE);
			}

			@Override
			public void onSusscess(String data)
			{
				AutoLocationSuccess(data);
			}

			@Override
			public void onError(String meg)
			{
				AntoLocationFilue();
			}
		});

	}

	/**
	 * 第二步之1: 自动定位成功，获取定位成功的城市名.返回的数据格式为 getCity&&getCity(深圳市);
	 */
	public void AutoLocationSuccess(String data)
	{

		String cityName = data.substring(17, 19);// 这里只要"深圳"二字

		getCityId(cityName);

		// btn_changeCity.setVisibility(View.VISIBLE);
		// pb_btn_changeCity.setVisibility(View.INVISIBLE);

		// btn_changeCity.setText("定位成功\n更改城市");
		// btn_changeCity.setTextSize(12);

		// 自动定位成功，点击按钮修改城市
		btn_changeCity.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0)
			{

				DialogInputCity();

			}
		});
	}

	/**
	 * 第二步之1:自动定位失败，手动输入当前城市
	 */
	public void AntoLocationFilue()
	{
		tv_titleCity.setText("");

		btn_changeCity.setVisibility(View.VISIBLE);
		pb_btn_changeCity.setVisibility(View.INVISIBLE);

		btn_changeCity.setText("定位失败\n点击输入");
		btn_changeCity.setTextSize(12);

		// 自动定位失败，点击按钮手动输入当前城市
		btn_changeCity.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View arg0)
			{

				DialogInputCity();

			}
		});
	}

	/**
	 * 第二步之2：弹出对话框手动输入城市：定位成功的情况下为切换城市；定位失败的情况下为输入当前城市
	 */
	public void DialogInputCity()
	{
		AlertDialog.Builder builder = new Builder(this);

		// 设置对话框不能在点击对话框之外消失
		builder.setCancelable(false);

		View view = View
				.inflate(getApplicationContext(), R.layout.dialog, null);

		final EditText et_city = (EditText) view.findViewById(R.id.et_city);
		Button btn_ok = (Button) view.findViewById(R.id.btn_ok);
		Button btn_cancel = (Button) view.findViewById(R.id.btn_cancel);

		// 设置对话框上的确定按钮的点击事件
		btn_ok.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View view)
			{
				String cityName = et_city.getText().toString().trim();

				if (TextUtils.isEmpty(cityName))
				{
					return;
				}

				tv_titleCity.setText(cityName);

				getCityId(cityName);

				dialog.dismiss();

			}

		});

		btn_cancel.setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				// 隐藏对话框
				dialog.dismiss();
			}
		});

		dialog = builder.create();

		dialog.setView(view);

		dialog.show();

	}

	/**
	 * 第三步：再次访问网络获取城市id
	 */
	public void getCityId(String cityName)
	{

		String cityNamePinYin = PinYinUtil.getPinyin(cityName);

		new HttpUtils().getMethod(getCityIdURL + cityNamePinYin,
				new HttpCallBack()
				{

					@Override
					public void onstart()
					{
						btn_changeCity.setVisibility(View.INVISIBLE);
						pb_btn_changeCity.setVisibility(View.VISIBLE);
					}

					@Override
					public void onSusscess(String data)
					{

						// btn_changeCity.setVisibility(View.VISIBLE);
						// pb_btn_changeCity.setVisibility(View.INVISIBLE);

						// btn_changeCity.setText("定位成功\n更改城市");
						// btn_changeCity.setTextSize(12);

						ParserCityIdData(data);

					}

					@Override
					public void onError(String meg)
					{

						Toast.makeText(getApplicationContext(), "无法获取当前城市天气情况",
								1).show();

						btn_changeCity.setVisibility(View.VISIBLE);
						pb_btn_changeCity.setVisibility(View.INVISIBLE);

						btn_changeCity.setText("定位失败\n点击输入");
						btn_changeCity.setTextSize(12);

					}
				});
	}

	/**
	 * 第四步：解析第二个接口得到的cityId数据
	 */
	public void ParserCityIdData(String data)
	{
		ArrayList<CityIdDataBean> beans = new ArrayList<CityIdDataBean>();

		try
		{
			JSONObject jsonObject = new JSONObject(data);

			// 注意：如果输入的是省或直辖市，则会得到这个省的所有市或者这个直辖市的所有区的天气情况，所以要循环解析
			JSONArray jsonArray = jsonObject.getJSONArray("results");

			for (int i = 0; i < jsonArray.length(); i++)
			{
				JSONObject jo = (JSONObject) jsonArray.get(i);

				CityIdDataBean bean = new CityIdDataBean();

				bean.setCityId(jo.getString("id"));
				bean.setCityName(jo.getString("name"));

				beans.add(bean);

			}

			/**
			 * 第五步：判断beans中数据的多少作出相应操作
			 */
			switch (beans.size())
			{
			case 0:// 数据解析成功，但是为空
				Toast.makeText(getApplicationContext(), "没有当前城市天气情况", 1).show();
				break;

			case 1:// 数据解析成功，只有一条数据，访问第四个接口数据
				getTenDayWeather(beans.get(0));
				break;

			default:// 数据解析成功，有多条数据，弹出对话框选择一条，再访问第四个接口数据
				selectOneDataDialog(beans);
				break;
			}

		} catch (JSONException e)
		{
			e.printStackTrace();
		}

	}

	/**
	 * 第六步：弹出单选对话框从多条数据中选择其中一条数据
	 */
	public void selectOneDataDialog(final ArrayList<CityIdDataBean> beans)
	{
		// 构建AlertDialog
		AlertDialog.Builder builder = new Builder(this);

		builder.setTitle("请选择其中一个城市：");

		final String[] datas = new String[beans.size()];
		for (int i = 0; i < beans.size(); i++)
		{
			datas[i] = beans.get(i).getCityName();
		}

		builder.setSingleChoiceItems(datas, -1,
				new DialogInterface.OnClickListener()
				{// 第二个参数是所选择的item，-1代表没有item被选中

					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						// dialog：接受点击的对话框
						// which ：被点击的按钮或者被点击的item的位置

						// 取出点中的条目：数据在哪存着就去哪儿取出
						String item = datas[which];

						tv_titleCity.setText(item);

						getTenDayWeather(beans.get(which));

						// 关闭当前对话框
						dialog.dismiss();
					}
				});

		// 最后一步一定要记得 show出来
		builder.show();

	}

	/**
	 * 第七步：访问第四个接口数据
	 */
	public void getTenDayWeather(CityIdDataBean bean)
	{

		new HttpUtils().getMethod(getTenDayWeatherURL + bean.getCityId(),
				new HttpCallBack()
				{

					@Override
					public void onstart()
					{

					}

					@Override
					public void onSusscess(String data)
					{

						Gson gson = new Gson();

						TenDayWeatherDataBean fromJsonData = gson.fromJson(
								data, TenDayWeatherDataBean.class);

						setView(fromJsonData);

					}

					@Override
					public void onError(String meg)
					{

					}
				});
	}

	/**
	 * 第八步：把数据设置给相应控件显示
	 */
	public void setView(TenDayWeatherDataBean fromJsonData)
	{

		// 设置标题和按钮，进度条
		tv_titleCity.setText(fromJsonData.weather.get(0).city_name);

		btn_changeCity.setVisibility(View.VISIBLE);
		pb_btn_changeCity.setVisibility(View.INVISIBLE);

		btn_changeCity.setText("定位成功\n更改城市");
		btn_changeCity.setTextSize(12);

		// 设置顶部天气情况
		tv_sunrise.setText(fromJsonData.weather.get(0).today.sunrise);
		tv_sunset.setText(fromJsonData.weather.get(0).today.sunset);

		if (fromJsonData.weather.get(0).now.code >= 0
				&& fromJsonData.weather.get(0).now.code <= 38)
		{
			iv_icon.setBackgroundResource(img_ids[(int) fromJsonData.weather
					.get(0).now.code]);
		} else
		{
			iv_icon.setBackgroundResource(img_ids[39]);
		}

		tv_text.setText(fromJsonData.weather.get(0).now.text);
		tv_temp.setText(fromJsonData.weather.get(0).now.temperature + " ℃");

		// 设置未来十天天气情况

		// 设置之前先把之前的数据清除
		hsl_ll.removeAllViews();

		ArrayList<FutureTenDayWeather> futureTenDay = fromJsonData.weather
				.get(0).future;

		for (int i = 0; i < futureTenDay.size(); i++)
		{
			FutureTenDayView ftdv = new FutureTenDayView(
					getApplicationContext());

			ftdv.setIv1Icon(img_ids[(int) futureTenDay.get(i).code1]);
			ftdv.setIv2Icon(img_ids[(int) futureTenDay.get(i).code2]);
			ftdv.setText(futureTenDay.get(i).text);
			ftdv.setHigh_Low(futureTenDay.get(i).high + " ℃/"
					+ futureTenDay.get(i).low + " ℃");
			ftdv.setWind(futureTenDay.get(i).wind);
			ftdv.setData_Time(futureTenDay.get(i).date + " "
					+ futureTenDay.get(i).day);

			hsl_ll.addView(ftdv);
		}

		// 以下为空气情况的控件设置数据

		tv_quality.setText("空气质量："
				+ fromJsonData.weather.get(0).now.air_quality.city.quality);
		tv_aqi.setText("AQI(空气污染指数)："
				+ fromJsonData.weather.get(0).now.air_quality.city.aqi
				+ " μg/m3");
		tv_humidity.setText("空气湿度：" + fromJsonData.weather.get(0).now.humidity
				+ " %");
		tv_pressure.setText("气压：" + fromJsonData.weather.get(0).now.pressure
				+ " Pa");
		tv_visibility.setText("能见度："
				+ fromJsonData.weather.get(0).now.visibility + " 米");
		tv_wind_direction.setText("风向："
				+ fromJsonData.weather.get(0).now.wind_direction);
		tv_wind_scale.setText("风力："
				+ fromJsonData.weather.get(0).now.wind_scale + " 级");
		tv_wind_speed.setText("风速："
				+ fromJsonData.weather.get(0).now.wind_speed + " m/s");
		tv_pm10.setText("Pm10："
				+ fromJsonData.weather.get(0).now.air_quality.city.pm10
				+ " mg/m3");
		tv_pm25.setText("Pm2.5："
				+ fromJsonData.weather.get(0).now.air_quality.city.pm25
				+ " mg/m3");
		tv_co.setText("CO："
				+ fromJsonData.weather.get(0).now.air_quality.city.co
				+ " mg/m3");
		tv_no2.setText("NO2："
				+ fromJsonData.weather.get(0).now.air_quality.city.no2
				+ " mg/m3");
		tv_o3.setText("O3："
				+ fromJsonData.weather.get(0).now.air_quality.city.o3
				+ " mg/m3");
		tv_so2.setText("SO2："
				+ fromJsonData.weather.get(0).now.air_quality.city.so2
				+ " mg/m3");

		// 设置数据给建议控件
		tv_car_washing_brief
				.setText("简述："
						+ fromJsonData.weather.get(0).today.suggestion.car_washing.brief);
		tv_car_washing_details
				.setText("详细："
						+ fromJsonData.weather.get(0).today.suggestion.car_washing.details);
		tv_dressing_brief.setText("简述："
				+ fromJsonData.weather.get(0).today.suggestion.dressing.brief);
		tv_dressing_detail
				.setText("详细："
						+ fromJsonData.weather.get(0).today.suggestion.dressing.details);
		tv_flu_brief.setText("简述："
				+ fromJsonData.weather.get(0).today.suggestion.flu.brief);
		tv_flu_details.setText("详细："
				+ fromJsonData.weather.get(0).today.suggestion.flu.details);
		tv_sport_brief.setText("简述："
				+ fromJsonData.weather.get(0).today.suggestion.sport.brief);
		tv_sport_details.setText("详细："
				+ fromJsonData.weather.get(0).today.suggestion.sport.details);
		tv_travel_brief.setText("简述："
				+ fromJsonData.weather.get(0).today.suggestion.travel.brief);
		tv_travel_details.setText("简述："
				+ fromJsonData.weather.get(0).today.suggestion.travel.details);
		tv_uv_brief.setText("简述："
				+ fromJsonData.weather.get(0).today.suggestion.uv.brief);
		tv_uv_details.setText("简述："
				+ fromJsonData.weather.get(0).today.suggestion.uv.details);
	}
}
