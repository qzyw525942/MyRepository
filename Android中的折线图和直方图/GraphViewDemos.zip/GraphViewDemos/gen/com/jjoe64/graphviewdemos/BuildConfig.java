/** Automatically generated file. DO NOT MODIFY */
package com.jjoe64.graphviewdemos;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}