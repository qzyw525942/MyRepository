package com.jjoe64.graphviewdemos;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.widget.LinearLayout;

import com.jjoe64.graphview.BarGraphView;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.LineGraphView;

public class AdvancedGraph extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.graphs);
		// graphs中就只有两个线性布局，放上下两个图表

		/**
		 * 第一步：画正弦曲线
		 */
		int num = 1500;// 设定采样取值个数为1500个数据
		GraphViewData[] data = new GraphViewData[num];// 创建一个容量为1500的数组

		// 定义sin函数自变量为v
		double v = 0;
		for (int i = 0; i < num; i++)
		{
			v += 0.2;
			// v每次增加0.2

			// 两个参数分别是x坐标值和y坐标值
			data[i] = new GraphViewData(v, Math.sin(v));
		}

		// 判断是要绘制直方图还是线形图
		GraphView graphView;
		if (getIntent().getStringExtra("type").equals("bar"))
		{
			graphView = new BarGraphView(this, "GraphViewDemo");

		} else
		{
			graphView = new LineGraphView(this, "GraphViewDemo");

		}

		// 将数据添加到graphView中去
		graphView.addSeries(new GraphViewSeries(data));

		// 设定当前屏幕要显示的图像范围：x坐标值从2~40的范围，后面的再往右拖可看到
		graphView.setViewPort(2, 40);

		// 设置图表可左右滚动
		graphView.setScrollable(true);

		// 将graphView添加到线性布局
		LinearLayout layout = (LinearLayout) findViewById(R.id.graph1);
		layout.addView(graphView);

		/**
		 * 第二步：画随机函数曲线
		 */
		num = 1500;
		data = new GraphViewData[num];
		v = 0;
		for (int i = 0; i < num; i++)
		{
			v += 0.2;
			data[i] = new GraphViewData(v, Math.sin(Math.random() * v));
		}

		// 设置画直方图还是线形图
		if (getIntent().getStringExtra("type").equals("bar"))
		{
			graphView = new BarGraphView(this, "GraphViewDemo");

		} else
		{
			graphView = new LineGraphView(this, "GraphViewDemo");
			((LineGraphView) graphView).setDrawBackground(true);// 画出曲线背景
		}

		// 添加数据
		graphView.addSeries(new GraphViewSeries(data));

		// 设定当前屏幕要显示的图像范围：x坐标值从2~40的范围，后面的再往右拖可看到
		graphView.setViewPort(4, 10);

		// 设置图表可左右滚动
		graphView.setScalable(true);

		// 设定y轴范围
		graphView.setManualYAxisBounds(2, -1);

		// 将graphView添加到线性布局
		layout = (LinearLayout) findViewById(R.id.graph2);
		layout.addView(graphView);
	}
}
