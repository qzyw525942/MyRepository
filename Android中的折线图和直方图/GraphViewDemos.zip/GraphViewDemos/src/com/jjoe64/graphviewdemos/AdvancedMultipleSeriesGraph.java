package com.jjoe64.graphviewdemos;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.widget.LinearLayout;

import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphView.LegendAlign;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.GraphViewSeries.GraphViewSeriesStyle;
import com.jjoe64.graphview.LineGraphView;

public class AdvancedMultipleSeriesGraph extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.graphs);

		// 画正弦函数
		int num = 1500;
		GraphViewData[] data = new GraphViewData[num];
		double v = 0;
		for (int i = 0; i < num; i++)
		{
			v += 0.2;
			data[i] = new GraphViewData(v, Math.sin(v));
		}

		// 设置正弦函数的描述，样式和数据
		GraphViewSeries seriesSin = new GraphViewSeries("Sinus curve",
				new GraphViewSeriesStyle(Color.rgb(200, 50, 00), 3), data);

		// 画余弦函数
		num = 1500;
		data = new GraphViewData[num];
		v = 0;
		for (int i = 0; i < num; i++)
		{
			v += 0.2;
			data[i] = new GraphViewData(v + 24, Math.cos(v));
		}

		// 设置余弦函数的描述，样式和数据
		GraphViewSeries seriesCos = new GraphViewSeries("Cosinus curve",
				new GraphViewSeriesStyle(Color.rgb(90, 250, 00), 3), data);

		// 画随机函数
		num = 1500;
		data = new GraphViewData[num];
		v = 0;
		for (int i = 0; i < num; i++)
		{
			v += 0.2;
			data[i] = new GraphViewData(v, Math.sin(Math.random() * v));
		}

		// 设置随机函数的描述，样式和数据
		GraphViewSeries seriesRnd = new GraphViewSeries("Random curve", null,
				data);

		// 画第一个线形图，注意：此界面没有直方图
		LineGraphView graphView = new LineGraphView(this, "GraphViewDemo");

		// 添加数据
		graphView.addSeries(seriesCos);
		graphView.addSeries(seriesSin);

		// 设置图例
		graphView.setShowLegend(true);

		graphView.setViewPort(2, 30);
		graphView.setScrollable(true);

		LinearLayout layout = (LinearLayout) findViewById(R.id.graph1);
		layout.addView(graphView);

		// 画第二个线形图：
		graphView = new LineGraphView(this, "GraphViewDemo");

		graphView.addSeries(seriesCos);
		graphView.addSeries(seriesSin);
		graphView.addSeries(seriesRnd);

		// 设置图例
		graphView.setShowLegend(true);
		graphView.setLegendAlign(LegendAlign.BOTTOM);// 图例对齐方式
		graphView.setLegendWidth(300);// 图例宽度

		graphView.setViewPort(2, 30);
		graphView.setScalable(true);

		layout = (LinearLayout) findViewById(R.id.graph2);
		layout.addView(graphView);
	}
}
