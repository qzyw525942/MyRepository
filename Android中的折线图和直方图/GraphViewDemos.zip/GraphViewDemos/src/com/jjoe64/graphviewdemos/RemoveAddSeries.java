package com.jjoe64.graphviewdemos;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.LineGraphView;

public class RemoveAddSeries extends Activity
{
	private GraphView graphView;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.graph_buttons);

		Button b1 = (Button) findViewById(R.id.button1);
		b1.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View arg0)
			{

				// x坐标的范围 0~30
				int count = 50;

				GraphViewData[] values = new GraphViewData[count];

				for (int i = 0; i < count; i++)
				{

					double y = Math.sin(i);

					values[i] = new GraphViewData(i, y);
				}

				GraphViewSeries series = new GraphViewSeries(values);

				graphView.addSeries(series);
			}
		});

		Button b2 = (Button) findViewById(R.id.button2);
		b2.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				graphView.removeAllSeries();
			}
		});

		graphView = new LineGraphView(this, "add remove series");

		LinearLayout ll = (LinearLayout) findViewById(R.id.linearLayout);
		ll.addView(graphView);
	}
}
