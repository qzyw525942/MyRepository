package com.jjoe64.graphviewdemos;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.widget.LinearLayout;

import com.jjoe64.graphview.BarGraphView;
import com.jjoe64.graphview.CustomLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.LineGraphView;

public class CustomLabelFormatterActivity extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.graphs);

		int size = 20;
		GraphViewData[] data = new GraphViewData[size];
		for (int i = 0; i < size; i++)
		{
			data[i] = new GraphViewData(i, new Random().nextInt(20));
		}

		GraphViewSeries exampleSeries = new GraphViewSeries(data);

		GraphView graphView;
		if (getIntent().getStringExtra("type").equals("bar"))
		{
			graphView = new BarGraphView(this, "GraphViewDemo");
		} else
		{
			graphView = new LineGraphView(this, "GraphViewDemo");
		}

		graphView.addSeries(exampleSeries);

		// 自定义坐标轴的值
		graphView.setCustomLabelFormatter(new CustomLabelFormatter()
		{
			@Override
			public String formatLabel(double value, boolean isValueX)
			{
				if (isValueX)
				{
					// 根据x轴的值的大小赋予相应的值
					if (value < 5)
					{
						return "small";

					} else if (value < 15)
					{
						return "middle";

					} else
					{
						return "big";
					}
				}

				return null; // 让graphView为我们生成y轴标签
			}
		});

		LinearLayout layout = (LinearLayout) findViewById(R.id.graph1);
		layout.addView(graphView);

		/**
		 * x轴为日期
		 */
		// 获取当前时间
		long now = new Date().getTime();

		data = new GraphViewData[size];
		for (int i = 0; i < size; i++)
		{
			data[i] = new GraphViewData(now + (i * 60 * 60 * 24 * 1000),
					new Random().nextInt(20)); // 第二天
		}

		exampleSeries = new GraphViewSeries(data);

		if (getIntent().getStringExtra("type").equals("bar"))
		{
			graphView = new BarGraphView(this, "GraphViewDemo");

		} else
		{
			graphView = new LineGraphView(this, "GraphViewDemo");

			((LineGraphView) graphView).setDrawBackground(true);
		}

		graphView.addSeries(exampleSeries);

		final SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d");

		graphView.setCustomLabelFormatter(new CustomLabelFormatter()
		{
			@Override
			public String formatLabel(double value, boolean isValueX)
			{
				if (isValueX)
				{
					Date d = new Date((long) value);

					return dateFormat.format(d);
				}

				return null; // 让graphView为我们生成y轴标签
			}
		});

		layout = (LinearLayout) findViewById(R.id.graph2);
		layout.addView(graphView);
	}
}
