package com.jjoe64.graphviewdemos;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.widget.LinearLayout;

import com.jjoe64.graphview.BarGraphView;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.GraphViewSeries.GraphViewSeriesStyle;
import com.jjoe64.graphview.LineGraphView;

public class StylesGraph extends Activity
{
	private final Handler mHandler = new Handler();

	private Runnable mTimer;

	private GraphViewSeries exampleSeries2;

	private double getRandom()
	{
		double high = 3;
		double low = 0.5;
		return Math.random() * (high - low) + low;
	}

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.graphs);

		/**
		 * 第一个图表：设置图表的其他属性
		 */
		GraphViewSeries exampleSeries = new GraphViewSeries(new GraphViewData[]
		{ new GraphViewData(1, 2.0d), new GraphViewData(2, 1.5d),
				new GraphViewData(2.5, 3.0d), new GraphViewData(3, 2.5d),
				new GraphViewData(4, 1.0d), new GraphViewData(5, 3.0d) });

		GraphView graphView;
		if (getIntent().getStringExtra("type").equals("bar"))
		{
			graphView = new BarGraphView(this, "GraphViewDemo");

		} else
		{
			graphView = new LineGraphView(this, "GraphViewDemo");
		}

		// 设置图表样式

		// 设置表格颜色
		graphView.getGraphViewStyle().setGridColor(Color.GREEN);

		// 设置x轴和y轴数字颜色
		graphView.getGraphViewStyle().setHorizontalLabelsColor(Color.YELLOW);
		graphView.getGraphViewStyle().setVerticalLabelsColor(Color.RED);

		// 设置文本大小
		graphView.getGraphViewStyle().setTextSize(30);

		// 设置当前屏幕上x轴和y轴要显示多少个单位长度
		graphView.getGraphViewStyle().setNumHorizontalLabels(7);
		graphView.getGraphViewStyle().setNumVerticalLabels(3);

		// 表格距离y轴数字的距离
		graphView.getGraphViewStyle().setVerticalLabelsWidth(100);

		graphView.addSeries(exampleSeries);

		LinearLayout layout = (LinearLayout) findViewById(R.id.graph1);
		layout.addView(graphView);

		/**
		 * 第二个图表：
		 */
		GraphViewSeriesStyle seriesStyle = new GraphViewSeriesStyle();

		exampleSeries2 = new GraphViewSeries("aaa", seriesStyle,
				new GraphViewData[]
				{ new GraphViewData(1, 2.0d), new GraphViewData(2, 1.5d),
						new GraphViewData(2.5, 3.0d),
						new GraphViewData(3, 2.5d), new GraphViewData(4, 1.0d),
						new GraphViewData(5, 3.0d) });

		graphView = new BarGraphView(this, "GraphViewDemo");
		graphView.addSeries(exampleSeries2);

		layout = (LinearLayout) findViewById(R.id.graph2);
		layout.addView(graphView);

	}

	@Override
	protected void onPause()
	{
		super.onPause();

		mHandler.removeCallbacks(mTimer);
	}

	@Override
	protected void onResume()
	{
		super.onResume();

		mTimer = new Runnable()
		{
			@Override
			public void run()
			{
				// 重置数据
				exampleSeries2.resetData(new GraphViewData[]
				{ new GraphViewData(1, getRandom()),
						new GraphViewData(2, getRandom()),
						new GraphViewData(2.5, getRandom()),
						new GraphViewData(3, getRandom()),
						new GraphViewData(4, getRandom()),
						new GraphViewData(5, getRandom()) });

				mHandler.postDelayed(this, 300);
			}
		};

		mHandler.postDelayed(mTimer, 300);
	}

}
