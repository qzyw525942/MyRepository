package com.jjoe64.graphviewdemos;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.widget.LinearLayout;

import com.jjoe64.graphview.BarGraphView;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.LineGraphView;

public class RealtimeGraph extends Activity
{
	private final Handler mHandler = new Handler();

	private Runnable mTimer1;
	private Runnable mTimer2;

	private GraphView graphView;

	private GraphViewSeries exampleSeries1;
	private GraphViewSeries exampleSeries2;

	private double graph2LastXValue = 5d;

	/**
	 * 获取随机值
	 */
	private double getRandom()
	{
		double high = 3;
		double low = 0.5;
		return Math.random() * (high - low) + low;
	}

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.graphs);

		/**
		 * 第一个图像
		 */
		exampleSeries1 = new GraphViewSeries(new GraphViewData[]
		{ new GraphViewData(1, 2.0d), new GraphViewData(2, 1.5d),
				new GraphViewData(2.5, 3.0d), new GraphViewData(3, 2.5d),
				new GraphViewData(4, 1.0d), new GraphViewData(5, 3.0d) });

		if (getIntent().getStringExtra("type").equals("bar"))
		{
			graphView = new BarGraphView(this, "GraphViewDemo");

		} else
		{
			graphView = new LineGraphView(this, "GraphViewDemo");
		}

		graphView.addSeries(exampleSeries1);

		LinearLayout layout = (LinearLayout) findViewById(R.id.graph1);
		layout.addView(graphView);

		/**
		 * 第二个图像
		 */
		exampleSeries2 = new GraphViewSeries(new GraphViewData[]
		{ new GraphViewData(1, 2.0d), new GraphViewData(2, 1.5d),
				new GraphViewData(2.5, 3.0d), new GraphViewData(3, 2.5d),
				new GraphViewData(4, 1.0d), new GraphViewData(5, 3.0d) });

		if (getIntent().getStringExtra("type").equals("bar"))
		{
			graphView = new BarGraphView(this, "GraphViewDemo");

		} else
		{
			graphView = new LineGraphView(this, "GraphViewDemo");
			((LineGraphView) graphView).setDrawBackground(true);
		}

		graphView.addSeries(exampleSeries2);

		graphView.setViewPort(1, 8);
		graphView.setScalable(true);

		layout = (LinearLayout) findViewById(R.id.graph2);
		layout.addView(graphView);
	}

	@Override
	protected void onPause()
	{
		super.onPause();

		mHandler.removeCallbacks(mTimer1);
		mHandler.removeCallbacks(mTimer2);
	}

	@Override
	protected void onResume()
	{
		super.onResume();

		mTimer1 = new Runnable()
		{
			@Override
			public void run()
			{
				// exampleSeries1重置数据
				exampleSeries1.resetData(new GraphViewData[]
				{ new GraphViewData(1, getRandom()),
						new GraphViewData(2, getRandom()),
						new GraphViewData(2.5, getRandom()),
						new GraphViewData(3, getRandom()),
						new GraphViewData(4, getRandom()),
						new GraphViewData(5, getRandom()) });

				mHandler.postDelayed(this, 500);
			}
		};

		mHandler.postDelayed(mTimer1, 500);

		mTimer2 = new Runnable()
		{
			@Override
			public void run()
			{
				graph2LastXValue += 1d;

				// exampleSeries2追加数据
				// 第二个参数是是否能划到最后
				// 第三个参数是最大可增加多少个数据
				exampleSeries2.appendData(new GraphViewData(graph2LastXValue,
						getRandom()), true, 10);

				mHandler.postDelayed(this, 800);
			}
		};
		mHandler.postDelayed(mTimer2, 1000);
	}
}
