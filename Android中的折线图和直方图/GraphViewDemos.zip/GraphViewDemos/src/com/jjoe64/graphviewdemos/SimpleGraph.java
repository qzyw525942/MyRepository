package com.jjoe64.graphviewdemos;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.widget.LinearLayout;

import com.jjoe64.graphview.BarGraphView;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphView.GraphViewData;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.GraphViewSeries.GraphViewSeriesStyle;
import com.jjoe64.graphview.GraphViewStyle;
import com.jjoe64.graphview.LineGraphView;

public class SimpleGraph extends Activity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.graphs);

		/**
		 * 第一个图表：
		 */

		// 第一个参数:折线图描述
		// 第二个参数:折线的显示样式，包含其颜色和宽度(折线粗细程度)
		// 第三个参数： 折线点数据，把这些点连接起来就能形成折线
		GraphViewSeries exampleSeries = new GraphViewSeries("vvvv",
				new GraphViewSeriesStyle(0xffff0000, 3), new GraphViewData[]
				{ new GraphViewData(1, 2.0d), new GraphViewData(2, 1.5d),
						new GraphViewData(2.5, 3.0d),
						new GraphViewData(3, 2.5d), new GraphViewData(4, 1.0d),
						new GraphViewData(5, 3.5d) });

		GraphView graphView;
		if (getIntent().getStringExtra("type").equals("bar"))
		{// 显示条形直方图

			// 两个参数分别是上下文和折线图标题
			graphView = new BarGraphView(this, "");

		} else
		{// 显示线性折线图

			// 两个参数分别是上下文和折线图标题
			graphView = new LineGraphView(this, "");
		}

		// 显示折线图描述
		graphView.setShowLegend(true);

		// 设置水平坐标点的值：从左到右
		graphView.setHorizontalLabels(new String[]
		{ "1", "2", "3", "4", "5" });

		// 设置垂直坐标点的值：从上到下
		graphView.setVerticalLabels(new String[]
		{ "4", "3", "2", "1" });

		// 设置折线图背景色
		graphView.setBackgroundColor(0x00000000);

		// 第一个参数：垂直坐标值的颜色
		// 第二个参数：水平坐标值的颜色
		// 第三个参数：坐标表格的颜色
		GraphViewStyle graphViewStyle = new GraphViewStyle(0xffff0000,
				0xff0000ff, 0xff00ff00);

		// 设置坐标值字体的大小
		graphViewStyle.setTextSize(30);

		// 将graphViewStyle设置给graphView
		graphView.setGraphViewStyle(graphViewStyle);

		// 将exampleSeries数据设置给graphView
		graphView.addSeries(exampleSeries);

		// 添加graphView到layout
		LinearLayout layout = (LinearLayout) findViewById(R.id.graph1);
		layout.addView(graphView);

		/**
		 * 第二个图表：
		 */
		// 自定义坐标值和折线图背景的折线图
		if (getIntent().getStringExtra("type").equals("bar"))
		{
			// 设置折线图标题为barGraphView。并且图形形状不变
			graphView = new BarGraphView(this, "barGraphView");

		} else
		{
			// 设置折线图标题为barGraphView。改变折线图形状
			graphView = new LineGraphView(this, "barGraphView");

			// 设置能绘画折线图背景
			((LineGraphView) graphView).setDrawBackground(true);

			// 设置折线图背景色
			((LineGraphView) graphView).setBackgroundColor(Color
					.rgb(80, 30, 30));
		}

		// 自定义坐标轴的值和添加数据
		graphView.setHorizontalLabels(new String[]
		{ "2 days ago", "yesterday", "today", "tomorrow" });

		graphView.setVerticalLabels(new String[]
		{ "high", "middle", "low" });

		graphView.addSeries(exampleSeries);

		layout = (LinearLayout) findViewById(R.id.graph2);
		layout.addView(graphView);
	}
}